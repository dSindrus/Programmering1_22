print("-----------------------------------")        #pynt
import random

random_number = random.randint(1,101)           # Lager en variabel med en tilfeldig tallverdi ved hjelp av randint(x,y)
print("-----\n", random_number, "\n-----")

print("-----------------------------------")        #pynt