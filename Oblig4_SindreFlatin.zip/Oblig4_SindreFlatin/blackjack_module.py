import random


full_deck = {"Two of clubs": 2, "Three of clubs": 3, "Four of clubs": 4, "Five of clubs": 5, "Six of clubs": 6,
             "Seven of clubs": 7, "Eight of clubs": 8, "Nine of clubs": 9, "Ten of clubs": 10,
             "Jack of clubs": 10, "Queen of clubs": 10, "King of clubs": 10, "Ace of clubs": 11,
             "Two of diamonds": 2, "Three of diamonds": 3, "Four of diamonds": 4, "Five of diamonds": 5,
             "Six of diamonds": 6, "Seven of diamonds": 7, "Eight of diamonds": 8, "Nine of diamonds": 9,
             "Ten of diamonds": 10, "Jack of diamonds": 10, "Queen of diamonds": 10, "King of diamonds": 10,
             "Ace of diamonds": 11,
             "Two of hearts": 2, "Three of hearts": 3, "Four of hearts": 4, "Five of hearts": 5, "Six of hearts": 6,
             "Seven of hearts": 7, "Eight of hearts": 8, "Nine of hearts": 9, "Ten of hearts": 10,
             "Jack of hearts": 10, "Queen of hearts": 10, "King of hearts": 10, "Ace of hearts": 11,
             "Two of spades": 2, "Three of spades": 3, "Four of spades": 4, "Five of spades": 5, "Six of spades": 6,
             "Seven of spades": 7, "Eight of spades": 8, "Nine of spades": 9, "Ten of spades": 10,
             "Jack of spades": 10, "Queen of spades": 10, "King of spades": 10, "Ace of spades": 11,
             }
deck_aces = {"Ace of spades": 11,
            "Ace of hearts": 11,
            "Ace of diamonds": 11,
            "Ace of clubs": 11,
}

def get_new_shuffled_deck():
    deck = list(full_deck.keys())
    random.shuffle(deck)
    return deck


def get_card_value(card):
    return full_deck[card]


'''def calculate_ace_player(player_hand, player_score):
    for full_deck.keys("ace") in player_hand:
        if player_score > 21:
            card.update({"value": 1})


def calculate_ace_dealer(dealer_hand, dealer_score):
    for full_deck.items() in dealer_hand:
        for key, value in full_deck.items():
            if key == "Ace" and dealer_score > 21:
                value.update({value: 1})'''

#1.5) Ess som 1, eller 11.


def calculate_hand_value(hand):
    hand_value = 0
    for card in hand:
        if "ace" in card and get_card_value(card) >= 11:
            hand_value += get_card_value(card)
            hand += 1
        else:
            hand_value += get_card_value(card)
    return hand_value