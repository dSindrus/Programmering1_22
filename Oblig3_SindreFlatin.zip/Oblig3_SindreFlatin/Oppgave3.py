print("---------------------")      #pynt

favoritt_mat = ["Solveigs Pizza", "Baconsnurra indrefilet", "Fly Chicken"]          #Oppretter liste over favorittretter/spisesteder. Solveigs pizza og fly chicken har for mye godt til å kun skrive en rett.
                                                                                    # #NotSponsored, men test de. Skammelig godt.
def print_list(favoritt_mat):
    for rett in favoritt_mat:               #definerer en funksjon som henter elementer fra listen, og printer disse
        print(rett)
print_list(favoritt_mat)                    #henter den definerte funksjonen med lista som utganspunkt.

print("---------------------")      #pynt