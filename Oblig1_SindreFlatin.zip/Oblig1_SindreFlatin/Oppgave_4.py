
a = 6
b = 3           # Her gis a-c bestemte verdier av typen int.
c = 2
print(" ")
print("Når a = 6, b = 3 og c = 2")          # Enkel definisjon av premissets verdier på de forskjellige variablene.

print ("----------------------------")      # Unødvendig, lagt inn for ordensskyld

print(f"a) Er da a+b*c: {a+b*c}")
print(f"b) Er da (a+b)*c: {(a+b)*c}")
print(f"c) Er da a/b/c: {a/b/c}")           # Her gjøres utregningene gitt i oppgaven med riktige operatorer
print(f"d) Er da a/(b/c): {a/(b/c)}")

print("----------------------------")       # Unødvendig, lagt inn for ordensskyld