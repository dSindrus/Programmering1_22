print("------------------------------------")       #pynt
student = {"first name": "Ola", "last name": "Nordmann",
           "favorite course": "programmering 1"}                    #oppretter en dictionary
#1
print(student["first name"] + " " + student["last name"])           #printer ut verdiene i nøklene first name, og last name.

print("------------------------------------")       #pynt

#2
student["favorite course"] = "ITF10219 Programmering 1"             #legger til en ny nøkkel med tilhørende verdi ved hjelp av [].
print(student)

print("------------------------------------")       #pynt

#3
student["alder"] = 28                                               #Legger til en ny nøkkel med tilhørende verdi ved hjelp av []
print(student)

print("------------------------------------")       #pynt