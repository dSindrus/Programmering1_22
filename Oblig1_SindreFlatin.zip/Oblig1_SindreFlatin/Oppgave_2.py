fornavn = "Sindre"                                                                                  # Her definerer jeg hva variabelen fornavn er som en string ved hjelp av "".
etternavn = "Flatin"                                                                                # Her definerer jeg hva variabelen etternavn er, som en string ved hjelp av "".
alder = 28                                                                                          # Her definerer jeg hva variabelen alder er som en int-verdi.

print("Hei! Jeg heter " + (fornavn) +" " + (etternavn) + " og er " + str(alder) + " år gammel.")    # Her bruker jeg print() for å få frem teksten med variablene, samtidig som jeg konverterte
                                                                                                    # int-variabelen (alder) til tekst ved hjelp av str()